# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '9dd0705b83bdb5b236b99b539e5b560ab01de73f78c2ca72fce370a8efd9a3e955e67b1a5ba7682d3a50f25d02fb13d3bb93ce55be3d5e08faa3e362bf5fb1e7'