class RemoveBoyFromLists < ActiveRecord::Migration[5.2]
  def change
    remove_column :lists, :boy, :string
  end
end
